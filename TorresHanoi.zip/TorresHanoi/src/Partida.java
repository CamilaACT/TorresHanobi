import java.util.Objects;
import java.util.Stack;

public class Partida {
    private int NumUsuarioMovimientos;
    private Stack<String> torreA;
    private Stack<String> torreB;
    private Stack<String> torreC;
    private int NumDiscos;
    private double NumMovimeintos;
    private boolean pararPartida;
    //private tableManagment tb;

    public Partida(int numDiscos1) {
        this.NumDiscos = numDiscos1;
        this.NumUsuarioMovimientos=0;
        this.pararPartida=false;
        this.NumMovimeintos=calcularMovimientosMinimos(numDiscos1);
        torreA=new Stack<String>();
        torreB=new Stack<String>();
        torreC=new Stack<String>();
        //tb=new tableManagment();
        cargarTorreA();
    }
    private double calcularMovimientosMinimos(int NumDiscos){
        return Math.pow(2,NumDiscos)-1;
    }

    public int sumarMovimientos(){
        return NumUsuarioMovimientos++;
    }
    public void restablecerPartida()
    {
        NumMovimeintos=0;
        NumUsuarioMovimientos=0;
    }

    private void cargarTorreA(){
        String datos="";
        for(int x=NumDiscos;x>=1;x--){
            datos+="#";
            torreA.add(datos);
        }
    }

    public String[] datosTorreA()
    {
        Stack<String> pilaCopia = new Stack<>();
        pilaCopia.addAll(torreA);
        String[] datos=new String[10];
        int posicion=9;
        while (!pilaCopia.isEmpty()) {
            datos[posicion]=pilaCopia.pop();
            posicion--;
        }

        return datos;
    }
    public String[] datosTorreB()
    {
        Stack<String> pilaCopia = new Stack<>();
        pilaCopia.addAll(torreB);
        String[] datos=new String[10];
        int posicion=9;
        while (!pilaCopia.isEmpty()) {
            datos[posicion]=pilaCopia.pop();
            posicion--;
        }

        return datos;
    }
    public String[] datosTorreC()
    {
        Stack<String> pilaCopia = new Stack<>();
        pilaCopia.addAll(torreC);
        String[] datos=new String[10];
        int posicion=9;
        while (!pilaCopia.isEmpty()) {
            datos[posicion]=pilaCopia.pop();
            posicion--;
        }

        return datos;
    }


    public double getNumMovimeintos() {
        return NumMovimeintos;
    }

    public int getNumUsuarioMovimientos() {
        return NumUsuarioMovimientos;
    }


}

